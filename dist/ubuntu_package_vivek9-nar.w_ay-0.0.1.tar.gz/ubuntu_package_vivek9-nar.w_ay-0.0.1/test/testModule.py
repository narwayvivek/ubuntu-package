import unittest

from ubuntu_package import module

class TestModule(unittest.TestCase):
    def test_module(self):
        self.assertEqual(5, module.add(2, 3))
        self.assertEqual(-1, module.subtract(2, 3))
        self.assertEqual(6, module.multiply(2, 3))
        self.assertEqual(5, module.divide(10, 2)) 