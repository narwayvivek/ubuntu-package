# Ubuntu Package

This is a simple package to perform mathematical operations on Ubuntu.